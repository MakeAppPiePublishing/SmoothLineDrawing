//
//  ContentView.swift
//  LineDrawing
//
//  Created by Steven Lipton on 9/30/20.
//

import SwiftUI


//var pathArray:[(Int,Int)] = [(100,100),(100,200),(112,275),(150,300),(200,300)]
var pathArray:[(Int,Int)] = [(0,100),(200,100),(100,300),(200,300),(200,450),(0,450),(0,125)]

func internalPoint(v1:CGFloat,v2:CGFloat,weight:CGFloat)->CGFloat{
    return ((weight-1)*v1 + v2) / weight 
}


func midPoint(start:CGPoint,end:CGPoint,weight:CGFloat = 2)->CGPoint{
    // find a midpoint
    //let midX = (end.x + start.x)/weight
    let midX = internalPoint(v1: start.x, v2: end.x, weight: weight)
    //let midY = (end.y + start.y)/weight
    let midY = internalPoint(v1: start.y, v2: end.y, weight: weight)
    
    return CGPoint(x: midX, y: midY)
}

func cgPoint(_ point:(Int,Int))->CGPoint{
    return CGPoint(x: point.0, y: point.1)
}

let mp = midPoint(start: cgPoint(pathArray[0]), end: cgPoint(pathArray[1]))



func point(_ point:CGPoint)->(Int,Int){
    return(Int(point.x),Int(point.y))
}
pathArray


//pathArray.insert(point(mp), at: 1)

func insertMidPoint(index:Int)-> CGPoint{
    let mp = midPoint(start: cgPoint(pathArray[index]), end: cgPoint(pathArray[index + 1]),weight: 2)
    pathArray.insert(point(mp), at: index + 1)
    return mp
}

func insertSurroundingPoints(index:Int){
     let mp0 = cgPoint(pathArray[index])
     let mp1 = insertMidPoint(index: index)
     let mp2 = insertMidPoint(index: index - 1)
     let mp3 = midPoint(start: mp2, end: mp1)
     let mp4 = midPoint(start: mp0, end: mp3)
    pathArray[index + 1] = point(mp4)
}

pathArray
func smoothPath(path:[(Int,Int)],smoothing:CGFloat)->[(Int,Int)]{
    var newPath:[(Int,Int)] = [path[0]]
    let lastIndex = path.count - 1
    for index in 1..<lastIndex{
        
        
        let mp0 = cgPoint(pathArray[index])
        let mp1 = midPoint(start: cgPoint(pathArray[index]), end: cgPoint(pathArray[index + 1]),weight: 2)
        let mp2 = midPoint(start: cgPoint(pathArray[index - 1]), end: cgPoint(pathArray[index]),weight: 2)
        let mp3 = midPoint(start: mp1, end: mp2,weight: 2)
        let mp4 = midPoint(start: mp0, end: mp3,weight:smoothing)
        newPath.append(point(mp2))
        newPath.append(point(mp4))
        newPath.append(point(mp1))
    }
    newPath.append(path[lastIndex])
    return newPath
}
pathArray = smoothPath(path: pathArray, smoothing: 1.5)
//pathArray = smoothPath(path: pathArray, smoothing: 2.5)

func length(start:CGPoint,end:CGPoint)-> CGFloat{
    let a = start.x - end.x
    let b = start.y - end.y
    let hSquared  = a * a + b * b
    return sqrt(hSquared)
}

var pathLength:CGFloat{
    var index = 0
    var total:CGFloat = 0
    while index < pathArray.count - 1{
        let start = CGPoint(x:pathArray[index].0,y:pathArray[index].1)
        let end = CGPoint(x:pathArray[index + 1].0,y:pathArray[index + 1].1)
        total += length(start: start, end: end)
        index += 1
    }
    return total
}
//
//
////chinge this to make an array so I can add the midpoint.
//func splitPath(start:CGPoint, end:CGPoint, segLength:CGFloat){
//    var midpoint = start
//    if length(start: start, end: end) > segLength{
//        // find a midpoint
//        midpoint = midPoint(start: start, end: end)
//        // split from the midpoint
//        splitPath(start: start, end: midpoint ,segLength: segLength)
//    }
//
//    //return the midpoint
//
//}
////NOtes: okay here's what you do. you find the midpoint of the line befoe(m1) and after(m2) your original point(o). you then find the midpoint between those two midpoints(m3). then you fidn the mid point(m4) between your original point(0) and that last midpoint(m3). you replace (o) with m1,m2 and m4.
//
struct ContentView: View {
    @State var color = Color.blue




    var body: some View {
        VStack{
            Text("PathLength \(pathLength)")
                .padding()
            ZStack{
                Path { path in
                    path.move(to: CGPoint(x: pathArray[0].0, y: pathArray[0].1))
                    for index in 1..<pathArray.count{
                        let currentPoint = CGPoint(x: pathArray[index].0, y: pathArray[index].1)
                        path.addLine(to: currentPoint)
                        path.move(to: currentPoint)
                    }
                }
                .stroke(Color.blue, style: StrokeStyle(lineWidth: 10, lineCap: .round, lineJoin: .round))
                Path{ path in
                    for index in 0..<pathArray.count{
                        let currentPoint = CGPoint(x: pathArray[index].0 - 5, y: pathArray[index].1 - 5)
                        path.move(to: currentPoint)
                        path.addEllipse(in: CGRect(origin: currentPoint, size: CGSize(width: 10, height: 10)))

                    }

                }
                .stroke(Color.red, style: StrokeStyle(lineWidth: 10, lineCap: .round, lineJoin: .round))
            }.frame(width: 400, height: 500, alignment: .center)
        }

    }
}

import PlaygroundSupport
PlaygroundPage.current.setLiveView(ContentView())
